# -*- coding: utf-8 -*-


from user.models import User
from websocket import trigger_event
import state
import settings

import logging
logger = logging.getLogger(__name__)

def api_requestPeering(user_id, username, message):
    event = 'peering.request'
    user = User.get_or_create(user_id)
    if not user.peered:
        pref = settings.preferences.get('receivedRequests')
        if pref == 'reject':
            return True
        if user.pending == 'sent' or pref == 'accept':
            user.info['message'] = message
            user.update_peering(True, username)
            user.update_name()
            event = 'peering.accept'
        else:
            user.pending = 'received'
            user.info['username'] = username
            user.info['message'] = message
            user.update_name()
        user.save()
        trigger_event(event, user.json())
        if user.peered:
            state.nodes.queue('add', user.id, True)
        return True
    return False

def api_acceptPeering(user_id, username, message):
    user = User.get(user_id, for_update=True)
    if user:
        logger.debug('incoming acceptPeering event: pending: %s', user.pending)
        if user.pending == 'sent':
            user.info['username'] = username
            user.info['message'] = message
            user.update_name()
            user.update_peering(True, username)
            state.nodes.queue('add', user.id, True)
            trigger_event('peering.accept', user.json())
            return True
        elif user.peered:
            return True
    return False

def api_rejectPeering(user_id, message):
    user = User.get(user_id, for_update=True)
    if user:
        user.info['message'] = message
        user.update_peering(False)
        trigger_event('peering.reject', user.json())
        return True
    return False

def api_removePeering(user_id, message):
    user = User.get(user_id, for_update=True)
    if user:
        user.info['message'] = message
        user.update_peering(False)
        trigger_event('peering.remove', user.json())
        return True
    return False

def api_cancelPeering(user_id, message):
    user = User.get(user_id, for_update=True)
    if user:
        user.info['message'] = message
        user.update_peering(False)
        trigger_event('peering.cancel', user.json())
        return True
    return False


def api_upload(user_id, items):
    from user.models import List
    peer = User.get(user_id)
    if peer:
        l = List.get_or_create(':Inbox')
        if l:
            logger.debug('%s added items to inbox: %s', user_id, items)
            l.add_items(items)
            trigger_event('change', {})
        return True
    return False
