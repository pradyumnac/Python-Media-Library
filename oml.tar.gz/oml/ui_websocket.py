# -*- coding: utf-8 -*-
import json


from tornado.websocket import WebSocketHandler
from tornado.ioloop import IOLoop

from oxtornado import json_dumps

import state
import settings
from websocket import trigger_event

import logging
logger = logging.getLogger(__name__)


class Handler(WebSocketHandler):

    queue = []

    def initialize(self, public=False):
        self._public = public

    def check_origin(self, origin):
        # allow access to websocket from site, installer and loader (local file)
        return self.request.host in origin or \
            origin in (
                'http://127.0.0.1:9841',
                'http://127.0.0.1:9842',
                'file://',
                'null'
            )

    def open(self):
        if self.request.headers['origin'] not in ('null', 'file://', 'http://127.0.0.1:9842') \
            and self.request.host not in self.request.headers['origin']:
            logger.debug('reject cross site attempt to open websocket %s', self.request)
            self.close()
        if self not in state.uisockets:
            state.uisockets.append(self)

    #websocket calls
    def on_message(self, message):
        if self.queue:
            action = self.queue.pop(0)
            trigger_event(action, {'path': message})
        else:
            print('no queue got:', message)

    def on_close(self):
        if self in state.uisockets:
            state.uisockets.remove(self)

    def post(self, message):
        if self.ws_connection is None:
            self.on_close()
        else:
            state.main.add_callback(lambda: self.write_message(message))

def trigger_ui(message):
    for ws in state.uisockets:
        try:
            ws.post(message)
        except:
            logger.debug('failed to send to UI ws %s %s', ws, message, exc_info=True)
