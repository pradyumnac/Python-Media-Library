# -*- coding: utf-8 -*-
from oxtornado import actions
from . import models
import settings
import state
from changelog import add_record

import logging
logger = logging.getLogger(__name__)


def getAnnotations(data):
    response = {}
    response['annotations'] = models.Annotation.get_by_item(data['id'])
    return response
actions.register(getAnnotations)


def addAnnotation(data):
    item_id = data.pop('item')
    a = models.Annotation.create(item_id, settings.USER_ID, data)
    a.add_record('addannotation')
    response = a.json()
    return response
actions.register(addAnnotation)


def editNote(data):
    a = models.Annotation.get(state.user(), data['item'], data['annotation'])
    if a:
        a.data['notes'] = data['notes']
        a.add_record('editannotation')
        a.save()
        response = a.json()
    else:
        response = {}
    return response
actions.register(editNote)


def removeAnnotation(data):
    a = models.Annotation.get(state.user(), data['item'], data['annotation'])
    if a:
        a.add_record('removeannotation')
        a.delete()
    response = {}
    return response
actions.register(removeAnnotation)
