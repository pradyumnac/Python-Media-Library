#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
from os.path import normpath, dirname, abspath, join
import site

base = normpath(dirname(dirname(dirname(abspath(__file__)))))

if sys.platform == 'win32':
    for site_packages in (
        join(base, 'openmedialibrary'),
        join(base, 'platform', 'Shared', 'lib', 'python3.4', 'site-packages'),
        join(base, 'platform', 'Shared', 'lib', 'python3.7', 'site-packages'),
        join(base, 'platform_win32', 'Lib', 'site-packages'),
    ):
        site.addsitedir(site_packages)
    sys.path.append(join(base, 'platform_win32'))
    os.environ['oxCACHE'] = join(base, 'data', 'ox')
    unrar_dll = join(base, 'platform_win32', 'unrar.dll')
    if os.path.exists(unrar_dll):
        os.environ['UNRAR_LIB_PATH'] = unrar_dll
    os.environ['TCL_LIBRARY'] = join(base, 'platform_win32', 'tcl', 'tcl8.6')

import api
import commands
import server

if len(sys.argv) > 1 and sys.argv[1] == 'server':
    server.run()
elif len(sys.argv) > 1 and sys.argv[1] == 'ui':
    import ui
    ui.main(sys.argv[2:])
else:
    commands.main()
if sys.platform == 'win32':
    # Work around pyopenssl exception to shutdown
    def handle_exception(*args, **kwargs):
        pass
    sys.excepthook = handle_exception
