# -*- coding: utf-8 -*-


from os.path import normpath, dirname, abspath, join
import json
import os
import subprocess
import sys

import ox
from oxtornado import actions

import item.api
import user.api
import annotation.api
import update
import utils

import logging
logger = logging.getLogger(__name__)

def win32_ui(type):
    base = normpath(dirname(dirname(dirname(abspath(__file__)))))
    cmd = [
        join('..', 'platform_win32', 'pythonw.exe'),
        join('oml', 'ui.py'), type
    ]
    return cmd

def selectFolder(data):
    '''
        returns {
            path
        }
    '''
    path = utils.ctl_output('ui', 'folder')
    if path == 'None':
        path = None
    return {
        'path': path
    }
actions.register(selectFolder, cache=False)


def selectFile(data):
    '''
        returns {
            path
        }
    '''
    path = utils.ctl_output('ui', 'file')
    if path == 'None':
        path = None
    return {
        'path': path
    }
actions.register(selectFile, cache=False)

def short_home(path):
    home = os.path.expanduser('~')
    if path and path.startswith(home):
        path = path.replace(home, '~')
    return path

def autocompleteFolder(data):
    '''
        takes {
            path
        }
        returns {
            items
        }
    '''
    path = data['path']
    path = os.path.expanduser(path)
    if os.path.isdir(path):
        if path.endswith('/') and path != '/':
            path = path[:-1]
        folder = path
        name = ''
    else:
        folder, name = os.path.split(path)
    if os.path.exists(folder):
        prefix, folders, files = next(os.walk(folder))
        folders = [os.path.join(prefix, f) for f in folders if (not name or f.startswith(name)) and not f.startswith('.')]
        if prefix == path:
            folders = [path] + folders
    else:
        folders = []
    folders = [short_home(f) for f in folders]
    return {
        'items': ox.sorted_strings(folders)
    }
actions.register(autocompleteFolder, cache=False)

def quit(data):
    '''
        takes {
        }
        returns {
        }
    '''
    import state
    state.main.stop()
    return {}
actions.register(quit, cache=False)

def logError(data):
    '''
        takes {
        }
        returns {
        }
    '''
    #logger.debug('frontend error %s', data)
    return {}
actions.register(logError, cache=False)
