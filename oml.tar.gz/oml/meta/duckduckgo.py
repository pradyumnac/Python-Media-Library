# -*- coding: utf-8 -*-


import ox.web.duckduckgo
import stdnum.isbn

from .utils import find_isbns

import logging
logger = logging.getLogger(__name__)


def find(query):
    logger.debug('find %s', query)
    query += ' isbn'
    isbns = []
    for r in ox.web.duckduckgo.find(query):
        isbns += find_isbns(' '.join(r))
    results = []
    done = set()
    for isbn in isbns:
        if isbn not in done:
            isbn = stdnum.isbn.to_isbn13(isbn)
            results.append(isbn)
            done.add(isbn)
            if len(isbn) == 13 and isbn.startswith('978'):
                done.add(stdnum.isbn.to_isbn10(isbn))
    return results
