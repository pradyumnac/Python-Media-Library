# -*- coding: utf-8 -*-


import stdnum.isbn
import ox

from . import google
from . import duckduckgo

from .utils import decode_html_data

from oml import settings

import logging
logger = logging.getLogger(__name__)


def find(title=None, author=None):
    results = google.find(title=title, author=author)
    # results = duckduckgo.find(query)
    '''
    results = openlibrary.find(query)
    for r in results:
        r['primaryid'] = 'olid'
    '''
    return results

def lookup_isbn(value):
    if not isvalid_id('isbn', value):
        return {}
    try:
        data = google.info(value)
    except:
        logger.debug('google.info failed for %s', value, exc_info=True)
        data = {}
    for key in [k['id'] for k in settings.config['itemKeys'] if isinstance(k['type'], list)]:
        if key in data and not isinstance(data[key], list):
            data[key] = [data[key]]
    data = decode_html_data(data)
    return data

def isvalid_id(key, value):
    if key == 'isbn':
        if len(value) not in (10, 13) or not stdnum.isbn.is_valid(value):
            return False
    if key == 'asin' and len(value) != 10:
        return False
    if key == 'olid' and not (value.startswith('OL') and value.endswith('M')):
        return False
    return True
