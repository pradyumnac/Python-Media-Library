# -*- coding: utf-8 -*-

import json
import os

from oml.pdict import pdict
from oml.utils import get_user_id
from oml import fulltext

base_dir = os.path.normpath(os.path.join(os.path.abspath(os.path.dirname(__file__)), '..'))
static_path = os.path.join(base_dir, 'static')
updates_path = os.path.normpath(os.path.join(base_dir, '..', 'updates'))

oml_data_path = os.path.join(base_dir, 'config.json')


data_path = os.path.normpath(os.path.join(base_dir, '..', 'data'))
if not os.path.exists(data_path):
    config_path = os.path.normpath(os.path.join(base_dir, '..', 'config'))
    if os.path.exists(config_path):
        data_path = config_path
    else:
        os.makedirs(data_path)

db_path = os.path.join(data_path, 'data.db')
log_path = os.path.join(data_path, 'debug.log')
ssl_cert_path = os.path.join(data_path, 'node.ssl.crt')
ssl_key_path = os.path.join(data_path, 'tor', 'private_key')


if os.path.exists(oml_data_path):
    with open(oml_data_path) as fd:
        config = json.load(fd)
else:
    config = {}

preferences = pdict(os.path.join(data_path, 'preferences.json'), config['user']['preferences'])
ui = pdict(os.path.join(data_path, 'ui.json'), config['user']['ui'])

server = pdict(os.path.join(data_path, 'server.json'))
server_defaults = {
    'port': 9842,
    'address': '127.0.0.1',
    'node_port': 9851,
    'public_address': '127.0.0.1',
    'public_port': 9852,
    'node_address': '',
    'extract_text': True,
    'localnode_discovery': True,
    'release_url': 'https://downloads.openmedialibrary.com/release.json',
    'pull_interval': 60000
}

for key in server_defaults:
    if key not in server:
        server[key] = server_defaults[key]

release = pdict(os.path.join(data_path, 'release.json'))

USER_ID = get_user_id(ssl_key_path, ssl_cert_path)

OML_UPDATE_KEY = 'K55EZpPYbP3X+3mA66cztlw1sSaUMqGwfTDKQyP2qOU'
OML_UPDATE_CERT = '''-----BEGIN CERTIFICATE-----
MIICgzCCAeygAwIBAgIBATANBgkqhkiG9w0BAQsFADAbMRkwFwYDVQQDDBBqc2pt
Z2J4ZjJvZGN6NGNxMB4XDTE1MTEyMzIwMzY1NFoXDTE1MTEyNDIwMzY1NFowGzEZ
MBcGA1UEAwwQanNqbWdieGYyb2RjejRjcTCBnzANBgkqhkiG9w0BAQEFAAOBjQAw
gYkCgYEAuUGGJPqtGaunUSWnnW6FO9WtMZUQkhjewlvZqFE8uQVcgeXVVmarpwjc
E/xFPYtDF5083jJs0UfCcJLpvWT5Y4pW8OCMmQl2JCxBiWsPTIYFtEizPbiZtMBs
xlEBmZRyB1mO/jSZ2ECmKf6yn2CJ4lY67Jlxy5/I963GZ9ZcHdECAwEAAaOB1jCB
0zASBgNVHRMBAf8ECDAGAQH/AgEAMBQGCWCGSAGG+EIBAQEB/wQEAwICBDB7BgNV
HSUBAf8EcTBvBggrBgEFBQcDAQYIKwYBBQUHAwIGCCsGAQUFBwMEBggrBgEFBQcD
CAYKKwYBBAGCNwIBFQYKKwYBBAGCNwIBFgYKKwYBBAGCNwoDAQYKKwYBBAGCNwoD
AwYKKwYBBAGCNwoDBAYJYIZIAYb4QgQBMAsGA1UdDwQEAwIBBjAdBgNVHQ4EFgQU
TJLDBuXThizwUMavAjjcm1mPu74wDQYJKoZIhvcNAQELBQADgYEAEyn9zfdrv7w9
GV47SOE+jJFhrSHsKGf0mKC1JDOJz1l9J1IYSnM7s8BcTBPpum2CJtc6braThH46
qvg7wm/8HUkrHouawZFudwTCGQEuUpe5AEQHGiBkBWiRwR9MIkfqE3aesrhDswb6
vZVVahubX7tZ0O1zUuCpn6E0uzh1aqg=
-----END CERTIFICATE-----'''

if 'modules' in release and 'openmedialibrary' in release['modules']:
    MINOR_VERSION = release['modules']['openmedialibrary']['version']
else:
    MINOR_VERSION = 'git'

NODE_PROTOCOL = "0.9"
VERSION = "%s.%s" % (NODE_PROTOCOL, MINOR_VERSION)

USER_AGENT = 'OpenMediaLibrary/%s' % VERSION

DEBUG_HTTP = server.get('debug_http', False)
DEBUG_API = server.get('debug_api', False)

FULLTEXT_SUPPORT = fulltext.platform_supported()

if not FULLTEXT_SUPPORT:
    config['itemKeys'] = [k for k in config['itemKeys'] if k['id'] != 'fulltext']

DB_VERSION = 20
