from threading import local

bandwidth = None
host = None
main = None
nodes = False
node = False
online = False
tasks = False
downloads = False
sync_enabled = True
tor = False
update = False
shutdown = False
websockets = []
uisockets = []
peers = {}
changelog_size = None

activity = {}
removepeer = {}
db = local()

def user():
    import settings
    import user.models
    return user.models.User.get_or_create(settings.USER_ID)

