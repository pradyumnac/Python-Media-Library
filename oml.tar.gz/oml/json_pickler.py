import json

def loads(*args, **kwargs):
    #print('loads', args, kwargs)
    if isinstance(args[0], bytes):
        args = (args[0].decode('utf-8'),) + args[1:]
    return json.loads(args[0], **kwargs)

def dumps(*args, **kwargs):
    #print('dumps', args, kwargs)
    kwargs['ensure_ascii'] = False
    return json.dumps(args[0], **kwargs).encode()
