import os
import sys
import settings

import ox
from utils import run

root_dir = os.path.dirname(settings.base_dir)

def install_autostart():
    if sys.platform == 'darwin':
        install_launchd()
    elif sys.platform == 'win32':
        install_autostart_win32()
    elif sys.platform.startswith('linux') or \
            os.path.exists(os.path.expanduser('~/.config/autostart')):
        install_autostart_xdg()
    else:
        print('no autostart support for %s' % sys.platform)


def uninstall_autostart():
    if sys.platform == 'darwin':
        name = 'com.openmedialibrary.loginscript'
        plist = os.path.expanduser('~/Library/LaunchAgents/%s.plist'%name)
        if os.path.exists(plist):
            run('launchctl', 'stop', name)
            run('launchctl', 'unload', plist)
            os.unlink(plist)
    elif sys.platform.startswith('linux'):
        for f in map(os.path.expanduser, [
            '~/.config/autostart/openmedialibrary.desktop'
        ]):
            if os.path.exists(f):
                os.unlink(f)
    elif sys.platform == 'win32':
        lnk = get_startup_path()
        if os.path.exists(lnk):
            os.unlink(lnk)

def install_launcher():
    if sys.platform.startswith('linux'):
        install_xdg()
    else:
        print('no launcher integration supported for %s' % sys.platform)

def uninstall_launcher():
    if sys.platform.startswith('linux'):
        for f in map(os.path.expanduser, [
            '~/.local/share/applications/openmedialibrary.desktop',
        ]):
            if os.path.exists(f):
                os.unlink(f)

def install_launchd():
    return
    name = 'com.openmedialibrary.loginscript'
    plist = os.path.expanduser('~/Library/LaunchAgents/%s.plist'%name)
    if os.path.exists(plist):
        run('launchctl', 'stop', name)
        run('launchctl', 'unload', plist)
    with open(plist, 'w') as f:
        f.write('''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%s</string>
    <key>ProgramArguments</key>
    <array>
        <string>%s/ctl</string>
        <string>autostart</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>''' % (name, root_dir))
    run('launchctl', 'load', plist)
    run('launchctl', 'start', name)

def install_xdg():
    app = os.path.expanduser('~/.local/share/applications/openmedialibrary.desktop')
    ox.makedirs(os.path.dirname(app))
    with open(app, 'w') as fd:
        fd.write('''[Desktop Entry]
Type=Application
Name=Open Media Library
Keywords=OpenMediaLibrary OML
Comment=manage and sync your digital media collections
Exec=%(base)s/ctl open
Icon=%(base)s/openmedialibrary/static/png/oml.png
Terminal=false
Categories=Network;FileTransfer;P2P;
''' % {'base': root_dir})

def install_autostart_xdg():
    app = os.path.expanduser('~/.config/autostart/openmedialibrary.desktop')
    ox.makedirs(os.path.dirname(app))
    with open(app, 'w') as fd:
        fd.write('''[Desktop Entry]
Type=Application
Name=Open Media Library
Comment=
Exec=%(base)s/ctl autostart
Icon=%(base)s/openmedialibrary/static/png/oml.png
Terminal=false
X-GNOME-Autostart-enabled=true
''' % {'base': root_dir})


def get_trayicon_version():
    from win32com.client import Dispatch
    ver_parser = Dispatch('Scripting.FileSystemObject')
    info = ver_parser.GetFileVersion(get_trayicon_path())
    if info == 'No Version Information Available':
        info = None
    return info

def get_trayicon_path():
    from win32com.client import Dispatch
    shell = Dispatch("WScript.Shell")
    applnk = os.path.join('C:\\', 'ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Open Media Library.lnk')
    if applnk and os.path.exists(applnk):
        app = shell.CreateShortCut(applnk)
        target = app.Targetpath
        return target

def get_startup_path():
    #return os.path.join('C:\\', 'ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Open Media Library.lnk')
    return os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Open Media Library.lnk')

def install_autostart_win32():
    from win32com.client import Dispatch
    shell = Dispatch("WScript.Shell")
    target = get_trayicon_path()
    if target:
        lnk = get_startup_path()
        shortcut = shell.CreateShortCut(lnk)
        shortcut.Targetpath = target
        shortcut.Arguments = '--autostart'
        shortcut.save()
